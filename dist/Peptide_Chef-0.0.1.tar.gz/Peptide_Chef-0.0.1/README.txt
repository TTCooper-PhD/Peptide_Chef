This is a very simple calculator and does basic math. 
